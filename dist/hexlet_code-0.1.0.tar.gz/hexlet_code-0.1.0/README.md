### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ribeyra/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ribeyra/python-project-49/actions)  
<a href="https://codeclimate.com/github/Ribeyra/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3d105c65b071d4b67b5c/maintainability" /></a>  
**Brain-even**  
[![asciicast](https://asciinema.org/a/jlc1BMRcqTgWSGoUD1p9XYMbw.svg)](https://asciinema.org/a/jlc1BMRcqTgWSGoUD1p9XYMbw)  
**Brain-calc**  
[![asciicast](https://asciinema.org/a/6Etf5TaTbiHKxIRShrlY3EXVE.svg)](https://asciinema.org/a/6Etf5TaTbiHKxIRShrlY3EXVE)  
**Brain-gcd**  
[![asciicast](https://asciinema.org/a/kPYFyJSgCqPcYR5k50HDzlL30.svg)](https://asciinema.org/a/kPYFyJSgCqPcYR5k50HDzlL30)  
