#!/usr/bin/env python3


def main():
    text = 'Welcome to the Brain Games!'
    print(text)


if __name__ == '__main__':
    main()
